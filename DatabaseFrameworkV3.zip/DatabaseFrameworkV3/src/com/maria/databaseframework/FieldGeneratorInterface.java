package com.maria.databaseframework;

public interface FieldGeneratorInterface {
	
	public String generateScript();

}
