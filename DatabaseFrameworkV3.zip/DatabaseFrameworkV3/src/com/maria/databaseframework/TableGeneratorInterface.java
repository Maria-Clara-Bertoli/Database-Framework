package com.maria.databaseframework;

public interface TableGeneratorInterface {
	
    String generateScript() throws Exception;
}
