package com.maria.databaseframework;

public interface SimpleTableGeneratorFactoryInterface {
	
	public SimpleTableGenerator createSimpleTableGenerator(SimpleTable simpleTable);

}
